//
//  AppDelegate.h
//  TEstTextFiled
//
//  Created by k on 2017/4/12.
//  Copyright © 2017年 king. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

