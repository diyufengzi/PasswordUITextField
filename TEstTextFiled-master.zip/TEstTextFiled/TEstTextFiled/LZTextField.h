//
//  LZTextField.h
//  TEstTextFiled
//
//  Created by k on 2017/4/12.
//  Copyright © 2017年 king. All rights reserved.
//

#import <UIKit/UIKit.h>

#define SCREEN_WIDTH CGRectGetWidth([UIScreen mainScreen].bounds)
#define SCREEN_HEIGTH CGRectGetHeight([UIScreen mainScreen].bounds)


@interface LZTextField : UIView

/**
 线条的颜色
 */
@property (nonatomic, weak) UIColor *hrImgColor;

/**
 文本框描边颜色
 */
@property (nonatomic, weak) UIColor *textFieldLayerColor;

/**
 文本框描边的宽度
 */
@property (nonatomic, assign) CGFloat textBorderWidth;
/**
 密码原点颜色
 */
@property (nonatomic, weak) UIColor *pwdTextColor;

/**
 密码圆点的宽高
 */
@property (nonatomic, assign) CGFloat pwdWidthOrHeight;

/**
 密码个数
 */
@property (nonatomic, assign) NSInteger pwdCountInt;
@property (nonatomic, weak) UITextField *pwTextField;


@end
