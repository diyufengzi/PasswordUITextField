//
//  LZTextField.m
//  TEstTextFiled
//
//  Created by k on 2017/4/12.
//  Copyright © 2017年 king. All rights reserved.
//

#import "LZTextField.h"
@interface LZTextField ()<UITextFieldDelegate>
/**
 线条集合
 */
@property (nonatomic, strong) NSMutableArray *hrImgeMary;
/**
 密码圆点集合
 */
@property (nonatomic, strong) NSMutableArray *pwdMary;

@end

@implementation LZTextField

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame: frame];
    if(self)
    {
        self.backgroundColor = [UIColor whiteColor];
        self.layer.borderColor = [UIColor redColor].CGColor;
        self.layer.cornerRadius = 8;
        self.layer.borderWidth = .5;
        self.clipsToBounds = YES;
        UITextField *pwTextField = [[UITextField alloc] init];
        pwTextField.textColor = [UIColor clearColor];
        //光标的颜色值
        pwTextField.tintColor = [UIColor whiteColor];
        pwTextField.keyboardType = UIKeyboardTypeNumberPad;
        //定义文本自动大小写样式。UITextAutocapitalizationTypeNone关闭自动大写
        pwTextField.autocapitalizationType = UITextAutocapitalizationTypeNone;
        pwTextField.textColor = self.backgroundColor;
        pwTextField.layer.borderWidth = 0.5;
        pwTextField.alpha = 0.1;
        [pwTextField addTarget:self action:@selector(textFieldDidChange:) forControlEvents:UIControlEventEditingChanged];
        pwTextField.delegate = self;
        [self addSubview:pwTextField];
        self.pwTextField = pwTextField;
    }
    return self;
}
- (NSMutableArray *)hrImgeMary
{
    if(!_hrImgeMary )
    {
        NSMutableArray *hrImgeMary = [NSMutableArray arrayWithCapacity:0];
        _hrImgeMary = hrImgeMary;
    }
    return _hrImgeMary;
}
- (NSMutableArray *)pwdMary
{
    if(!_pwdMary)
    {
        NSMutableArray *pwdMary = [NSMutableArray arrayWithCapacity:0];
        _pwdMary = pwdMary;
    }
    return  _pwdMary;
}
- (void)setPwdCountInt:(NSInteger)pwdCountInt
{
    _pwdCountInt = pwdCountInt;
    CGFloat hrImgViewWidth = CGRectGetWidth(self.bounds) / pwdCountInt;
    CGFloat subViewSHeigth = CGRectGetHeight(self.bounds);
    self.pwTextField.frame = CGRectMake(0, 0, CGRectGetWidth(self.bounds), subViewSHeigth);
    //分割线
    for(int i = 0 ; i < pwdCountInt - 1; i++)
    {
        UIImageView *hrImgView = [[UIImageView alloc] initWithFrame:CGRectMake((i + 1 )*hrImgViewWidth, 0, 1, subViewSHeigth)];
        [self.hrImgeMary addObject:hrImgView];
        [self addSubview:hrImgView];
    }
    //密码点
    for (int i = 0 ; i < pwdCountInt; i++) {
        UIView *pwdViw = [[UIView alloc] initWithFrame:CGRectMake(i * hrImgViewWidth + hrImgViewWidth / 2,
                                                                (subViewSHeigth - self.pwdWidthOrHeight) / 2,
                                                                self.pwdWidthOrHeight,
                                                                self.pwdWidthOrHeight)];
        
        
        
        pwdViw.hidden = YES;
        pwdViw.backgroundColor = [UIColor redColor];
        pwdViw.layer.cornerRadius = _pwdWidthOrHeight / 2;
        pwdViw.backgroundColor = self.pwdTextColor;
        pwdViw.clipsToBounds = YES;
        [self.pwdMary addObject:pwdViw];
        [self addSubview:pwdViw];
    }
}
- (void)setTextFieldLayerColor:(UIColor *)textFieldLayerColor
{
    self.layer.borderColor = textFieldLayerColor.CGColor;
}

- (void)setPwdWidthOrHeight:(CGFloat)pwdWidthOrHeight
{
    _pwdWidthOrHeight = pwdWidthOrHeight;
}
- (void)textFieldDidChange:(UITextField *)uiTextField
{
    for(UIView *objectView in self.pwdMary)
    {
        if([objectView isKindOfClass:[UIView class]])
        {
            objectView.hidden = YES;
        }
    }
    for(int i = 0 ; i < uiTextField.text.length ; i++)
    {
        UIView *pwdView = (UIView *)[self.pwdMary objectAtIndex:i];
        pwdView.hidden = NO;
    }
}
- (void)setHrImgColor:(UIColor *)hrImgColor
{
    for (UIView *hrimgeView in self.hrImgeMary) {
        if([hrimgeView isKindOfClass:[UIImageView class]])hrimgeView.backgroundColor = hrImgColor;
    }
}
- (void)setPwdTextColor:(UIColor *)pwdTextColor
{
    for(UIView *objectView in self.pwdMary)
    {
        objectView.backgroundColor = pwdTextColor;
    }
}
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    //屏蔽表情输入
    if([[[UITextInputMode currentInputMode]primaryLanguage] isEqualToString:@"emoji"] && string.length)
    {
        return NO;
    }
    if(string.length == 0) {
        //判断是不是删除键
        return YES;
    }
    if(textField.text.length >= self.pwdCountInt) {
        return NO;
    }
    return YES;
}
@end
