//
//  ViewController.m
//  TEstTextFiled
//
//  Created by k on 2017/4/12.
//  Copyright © 2017年 king. All rights reserved.
//

#import "ViewController.h"
#import "LZTextField.h"

@interface ViewController ()<UITextFieldDelegate>
@property (nonatomic, strong)LZTextField *lzTextField;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    [self creatUI];
}
- (void)creatUI
{
    LZTextField *lzTextField = [[LZTextField alloc] initWithFrame:CGRectMake(16, 100, SCREEN_WIDTH - 32, 50)];
    lzTextField.pwdWidthOrHeight = 10;
    lzTextField.pwdCountInt = 6;
    lzTextField.pwdTextColor = [UIColor redColor];
    lzTextField.textFieldLayerColor = [UIColor blueColor];
    lzTextField.hrImgColor = [UIColor purpleColor];
    [self.view addSubview:lzTextField];
    self.lzTextField = lzTextField;
}
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self.lzTextField.pwTextField resignFirstResponder];
    NSLog(@"pwdTextFieldValue:%@",self.lzTextField.pwTextField.text);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
